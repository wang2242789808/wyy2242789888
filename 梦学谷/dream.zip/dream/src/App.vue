<template>
  <div id="app">
   
    <router-view/>
  </div>
</template>

<style lang="scss">
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.el-input{
  margin: 10px;
}
</style>
